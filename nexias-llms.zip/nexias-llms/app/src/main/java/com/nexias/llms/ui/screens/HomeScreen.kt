package com.nexias.llms.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexias.llms.data.AppRepository
import com.nexias.llms.data.Compatibility
import com.nexias.llms.ui.components.EmptyState

@Composable
fun HomeScreen(
    onNewChat: () -> Unit,
    onOpenChat: (String) -> Unit,
    onNavigate: (String) -> Unit
) {
    val models by AppRepository.models.collectAsState()
    val activeModelId by AppRepository.activeModelId.collectAsState()
    val activeModel = models.find { it.id == activeModelId }
    val conversations by AppRepository.conversations.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("NEXIAS LLMs", style = MaterialTheme.typography.headlineSmall)
                Text("Good to see you", style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Current Model", style = MaterialTheme.typography.titleMedium)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (activeModel != null) {
                            Text(activeModel.name, style = MaterialTheme.typography.titleMedium)
                            Text(
                                "${activeModel.paramCount} • ${activeModel.quantization}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            val statusText = when (activeModel.compatibility) {
                                Compatibility.RECOMMENDED -> "Ready • Recommended for this device"
                                Compatibility.POSSIBLE -> "Ready • Possible on this device"
                                Compatibility.NOT_RECOMMENDED -> "Not recommended for this device"
                                Compatibility.UNSUPPORTED -> "Unsupported on this device"
                            }
                            Text(statusText, style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary)
                        } else {
                            Text("No model selected", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Add a compatible local model to get started",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                Button(onClick = onNewChat, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                    Text("New Chat")
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Quick Access", style = MaterialTheme.typography.titleMedium)
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 0.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val quick = listOf(
                        Triple("Models", Icons.Filled.Widgets, "models"),
                        Triple("History", Icons.Filled.History, "history"),
                        Triple("Notes", Icons.Filled.Description, "notes"),
                        Triple("Messages", Icons.Filled.Mail, "messages")
                    )
                    items(quick) { (label, icon, route) ->
                        OutlinedCard(
                            onClick = { onNavigate(route) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.Start,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Text(label, style = MaterialTheme.typography.titleMedium)
                            }
                        }
                    }
                }
            }
        }

        item {
            OutlinedCard(onClick = { onNavigate("ai_power") }, modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Filled.Bolt, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Text("AI Power", style = MaterialTheme.typography.titleMedium)
                    }
                    Text("Balanced", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        item {
            Text("Recent Chats", style = MaterialTheme.typography.titleMedium)
        }

        if (conversations.isEmpty()) {
            item {
                EmptyState(
                    icon = Icons.Filled.Chat,
                    title = "No Chats",
                    description = "Your conversations will appear here.",
                    actionLabel = "New Chat",
                    onAction = onNewChat
                )
            }
        } else {
            items(conversations.take(5)) { conv ->
                OutlinedCard(onClick = { onOpenChat(conv.id) }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(conv.title, style = MaterialTheme.typography.titleMedium)
                        Text(
                            conv.modelName,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
