package com.nexias.llms.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexias.llms.data.AppRepository
import com.nexias.llms.ui.components.SectionCard
import kotlinx.coroutines.flow.MutableStateFlow

@Composable
fun PrivacyScreen() {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Privacy", style = MaterialTheme.typography.headlineSmall)

        SectionCard {
            Text("Local by default", style = MaterialTheme.typography.titleMedium)
            Text(
                "Your chats, notes, messages, and local model files stay on this device unless you explicitly enable an external service below.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium
            )
        }

        SectionCard {
            ToggleRow("Local-only Mode", AppRepository.localOnlyMode)
            ToggleRow("Cloud AI", AppRepository.cloudAiEnabled)
            ToggleRow("Analytics", AppRepository.analyticsEnabled)
            ToggleRow("Crash Reports", AppRepository.crashReportsEnabled)
            ToggleRow("Online Model Discovery", AppRepository.onlineModelDiscoveryEnabled)
        }

        SectionCard {
            Text("What we never collect", style = MaterialTheme.typography.titleMedium)
            Text(
                "Message content, notes, and model files are never transmitted off this device unless you turn on Cloud AI or Online Model Discovery above.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun ToggleRow(label: String, flow: MutableStateFlow<Boolean>) {
    val value by flow.collectAsState()
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Switch(checked = value, onCheckedChange = { flow.value = it })
    }
}
