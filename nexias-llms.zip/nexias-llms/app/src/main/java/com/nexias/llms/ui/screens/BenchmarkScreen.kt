package com.nexias.llms.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexias.llms.ui.components.SectionCard
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

private data class BenchResult(
    val tokensPerSec: Double,
    val loadSeconds: Double,
    val ramMb: Int,
    val stability: String
)

@Composable
fun BenchmarkScreen() {
    var running by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<BenchResult?>(null) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Benchmark", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Runs the loaded model through a short generation pass to measure real on-device performance. " +
                "Note: without a native inference engine wired in yet, this uses simulated timings as a placeholder — " +
                "swap in real measurements once a RuntimeAdapter is implemented.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium
        )

        Button(
            onClick = {
                running = true
                result = null
                scope.launch {
                    delay(1800)
                    result = BenchResult(
                        tokensPerSec = Random.nextDouble(3.0, 14.0),
                        loadSeconds = Random.nextDouble(3.0, 12.0),
                        ramMb = Random.nextInt(500, 1800),
                        stability = "Good"
                    )
                    running = false
                }
            },
            enabled = !running,
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (running) "Running…" else "Run Benchmark") }

        if (running) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CircularProgressIndicator()
                Text("Measuring load time, throughput, RAM usage…")
            }
        }

        result?.let { r ->
            SectionCard {
                Text("Performance", style = MaterialTheme.typography.titleMedium)
                Text("Speed        ${"%.1f".format(r.tokensPerSec)} tok/s")
                Text("Load         ${"%.1f".format(r.loadSeconds)} sec")
                Text("RAM          ~${r.ramMb} MB")
                Text("Stability    ${r.stability}")
            }
        }
    }
}
