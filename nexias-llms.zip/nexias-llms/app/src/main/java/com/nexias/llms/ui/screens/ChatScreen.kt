package com.nexias.llms.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexias.llms.data.AppRepository
import com.nexias.llms.data.ChatMessage
import com.nexias.llms.data.Conversation
import com.nexias.llms.data.Role
import com.nexias.llms.runtime.RuntimeManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(conversationId: String) {
    val conversations by AppRepository.conversations.collectAsState()
    val activeModelId by AppRepository.activeModelId.collectAsState()
    val models by AppRepository.models.collectAsState()
    val modelName = models.find { it.id == activeModelId }?.name ?: "No model"

    var conversation = conversations.find { it.id == conversationId }
    if (conversation == null) {
        conversation = Conversation(id = conversationId, title = "New Chat", modelName = modelName)
        AppRepository.addConversation(conversation)
    }
    val conv = conversation

    var input by remember { mutableStateOf("") }
    var isGenerating by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var genJob: Job? by remember { mutableStateOf(null) }
    val listState = rememberLazyListState()

    LaunchedEffect(conv.messages.size) {
        if (conv.messages.isNotEmpty()) listState.animateScrollToItem(conv.messages.size - 1)
    }

    fun send(text: String) {
        if (text.isBlank() || isGenerating) return
        conv.messages.add(ChatMessage(role = Role.USER, initialText = text))
        val assistantMsg = ChatMessage(role = Role.ASSISTANT, initialText = "")
        conv.messages.add(assistantMsg)
        AppRepository.updateConversation(conv)
        input = ""
        isGenerating = true
        genJob = scope.launch {
            RuntimeManager.active.generate(text, temperature = 0.7f, maxTokens = 512).collect { token ->
                assistantMsg.text.value += token
            }
            isGenerating = false
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(conv.messages, key = { it.id }) { msg ->
                MessageBubble(msg)
            }
            if (isGenerating && conv.messages.lastOrNull()?.text?.value.isNullOrEmpty()) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(modifier = Modifier.padding(2.dp))
                        Text("Thinking…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message $modelName…") },
                shape = MaterialTheme.shapes.large
            )
            if (isGenerating) {
                IconButton(onClick = {
                    genJob?.cancel()
                    isGenerating = false
                }) { Icon(Icons.Filled.Stop, contentDescription = "Stop generating") }
            } else {
                IconButton(onClick = { send(input) }) {
                    Icon(Icons.Filled.Send, contentDescription = "Send")
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(msg: ChatMessage) {
    val isUser = msg.role == Role.USER
    val alignment = if (isUser) Alignment.End else Alignment.Start
    val containerColor = if (isUser) MaterialTheme.colorScheme.primaryContainer
        else MaterialTheme.colorScheme.surfaceVariant

    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = alignment) {
        Card(
            colors = CardDefaults.cardColors(containerColor = containerColor),
            shape = MaterialTheme.shapes.large
        ) {
            Text(
                text = msg.text.ifBlank { " " },
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}
