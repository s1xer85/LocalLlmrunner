package com.nexias.llms.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun NexiasTheme(content: @Composable () -> Unit) {
    val systemDark = isSystemInDarkTheme()
    val isDark = when (ThemeState.mode.value) {
        AppThemeMode.LIGHT -> false
        AppThemeMode.DARK -> true
        AppThemeMode.SYSTEM -> systemDark
    }

    val primary = ThemeState.primaryColor.value
    val accent = ThemeState.accentColor.value

    val colorScheme = if (isDark) {
        darkColorScheme(
            primary = primary,
            secondary = accent,
            background = ThemeState.backgroundDark.value,
            surface = ThemeState.backgroundDark.value.copy(alpha = 1f)
        )
    } else {
        lightColorScheme(
            primary = primary,
            secondary = accent,
            background = ThemeState.backgroundLight.value,
            surface = ThemeState.backgroundLight.value
        )
    }

    val radius = ThemeState.cornerRadius.value.dp
    val shapes = Shapes(
        extraSmall = RoundedCornerShape(radius / 2),
        small = RoundedCornerShape(radius * 0.75f),
        medium = RoundedCornerShape(radius),
        large = RoundedCornerShape(radius * 1.25f),
        extraLarge = RoundedCornerShape(radius * 1.5f)
    )

    val scale = ThemeState.fontScale.value
    val typography = Typography(
        headlineSmall = TextStyle(fontSize = (22 * scale).sp, fontWeight = FontWeight.SemiBold),
        titleLarge = TextStyle(fontSize = (18 * scale).sp, fontWeight = FontWeight.SemiBold),
        titleMedium = TextStyle(fontSize = (16 * scale).sp, fontWeight = FontWeight.Medium),
        bodyLarge = TextStyle(fontSize = (15 * scale).sp),
        bodyMedium = TextStyle(fontSize = (14 * scale).sp),
        labelSmall = TextStyle(fontSize = (11 * scale).sp)
    )

    MaterialTheme(
        colorScheme = colorScheme,
        shapes = shapes,
        typography = typography,
        content = content
    )
}
