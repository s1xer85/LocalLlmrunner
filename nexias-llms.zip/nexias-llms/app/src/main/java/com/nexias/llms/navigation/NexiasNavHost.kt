package com.nexias.llms.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import androidx.navigation.NavType
import androidx.compose.runtime.getValue
import java.util.UUID
import com.nexias.llms.ui.screens.AboutScreen
import com.nexias.llms.ui.screens.AddModelScreen
import com.nexias.llms.ui.screens.AiPowerScreen
import com.nexias.llms.ui.screens.BenchmarkScreen
import com.nexias.llms.ui.screens.ChatScreen
import com.nexias.llms.ui.screens.CustomizeScreen
import com.nexias.llms.ui.screens.DataStorageScreen
import com.nexias.llms.ui.screens.HelpScreen
import com.nexias.llms.ui.screens.HistoryScreen
import com.nexias.llms.ui.screens.HomeScreen
import com.nexias.llms.ui.screens.MessagesScreen
import com.nexias.llms.ui.screens.ModelsScreen
import com.nexias.llms.ui.screens.MoreScreen
import com.nexias.llms.ui.screens.NotesScreen
import com.nexias.llms.ui.screens.PrivacyScreen
import com.nexias.llms.ui.screens.SettingsScreen

private data class BottomItem(val dest: Dest, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val bottomItems = listOf(
    BottomItem(Dest.Home, Icons.Filled.Home),
    BottomItem(Dest.Models, Icons.Filled.Widgets),
    BottomItem(Dest.History, Icons.Filled.Chat),
    BottomItem(Dest.More, Icons.Filled.MoreHoriz)
)

@Composable
fun NexiasNavHost() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = backStackEntry?.destination
            NavigationBar {
                bottomItems.forEach { item ->
                    val selected = currentDestination?.hierarchy?.any { it.route == item.dest.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(item.dest.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(item.icon, contentDescription = item.dest.label) },
                        label = { Text(item.dest.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Dest.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Dest.Home.route) {
                HomeScreen(
                    onNewChat = { navController.navigate(Dest.Chat.route(UUID.randomUUID().toString())) },
                    onOpenChat = { id -> navController.navigate(Dest.Chat.route(id)) },
                    onNavigate = { route -> navController.navigate(route) }
                )
            }
            composable(
                route = Dest.Chat.route,
                arguments = listOf(navArgument("conversationId") { type = NavType.StringType })
            ) { backStackEntry ->
                val id = backStackEntry.arguments?.getString("conversationId") ?: UUID.randomUUID().toString()
                ChatScreen(conversationId = id)
            }
            composable(Dest.Models.route) {
                ModelsScreen(onAddModel = { navController.navigate(Dest.AddModel.route) })
            }
            composable(Dest.AddModel.route) {
                AddModelScreen(onDone = { navController.popBackStack() })
            }
            composable(Dest.History.route) {
                HistoryScreen(onOpenChat = { id -> navController.navigate(Dest.Chat.route(id)) })
            }
            composable(Dest.Notes.route) { NotesScreen() }
            composable(Dest.Messages.route) { MessagesScreen() }
            composable(Dest.AiPower.route) { AiPowerScreen() }
            composable(Dest.Benchmark.route) { BenchmarkScreen() }
            composable(Dest.Customize.route) { CustomizeScreen() }
            composable(Dest.Settings.route) { SettingsScreen(onNavigate = { route -> navController.navigate(route) }) }
            composable(Dest.Privacy.route) { PrivacyScreen() }
            composable(Dest.DataStorage.route) { DataStorageScreen() }
            composable(Dest.About.route) { AboutScreen() }
            composable(Dest.Help.route) { HelpScreen() }
            composable(Dest.More.route) { MoreScreen(onNavigate = { route -> navController.navigate(route) }) }
        }
    }
}
