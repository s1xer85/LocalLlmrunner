package com.nexias.llms.data

import androidx.compose.runtime.mutableStateOf
import java.util.UUID

enum class Compatibility { RECOMMENDED, POSSIBLE, NOT_RECOMMENDED, UNSUPPORTED }

data class LocalModel(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val creator: String,
    val paramCount: String,      // e.g. "0.6B"
    val quantization: String,    // e.g. "Q4_K_M"
    val sizeMb: Int,
    val architecture: String,    // e.g. "Qwen2"
    val runtime: String,         // e.g. "GGUF / llama.cpp adapter"
    val estimatedRamMb: Int,
    val compatibility: Compatibility,
    val license: String = "Unknown"
)

/**
 * `text` is a Compose MutableState (not a plain var) so that streamed token
 * updates during generation trigger recomposition of just the message bubble
 * that's changing, even though the ChatMessage object itself is mutated in place.
 */
class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: Role,
    initialText: String = "",
    val timestamp: Long = System.currentTimeMillis()
) {
    val text = mutableStateOf(initialText)
}

enum class Role { USER, ASSISTANT, SYSTEM }

data class Conversation(
    val id: String = UUID.randomUUID().toString(),
    var title: String,
    val modelName: String,
    val messages: MutableList<ChatMessage> = mutableListOf(),
    var pinned: Boolean = false,
    var favorite: Boolean = false,
    var archived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

data class NoteItem(
    val id: String = UUID.randomUUID().toString(),
    var title: String,
    var body: String,
    var pinned: Boolean = false,
    var favorite: Boolean = false,
    var tags: MutableList<String> = mutableListOf(),
    val createdAt: Long = System.currentTimeMillis()
)

enum class PromptCategory { SAVED, SYSTEM, CHARACTER, TEMPLATE, INSTRUCTION }

data class SavedPrompt(
    val id: String = UUID.randomUUID().toString(),
    var title: String,
    var content: String,
    var category: PromptCategory = PromptCategory.SAVED,
    var favorite: Boolean = false
)

enum class PerformanceProfile { ULTRA_LOW, LOW, BALANCED, HIGH, MAXIMUM }

enum class PowerPreset { FAST, BALANCED, QUALITY, CUSTOM }
