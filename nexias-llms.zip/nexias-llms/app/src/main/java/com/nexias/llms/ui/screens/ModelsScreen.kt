package com.nexias.llms.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.nexias.llms.data.AppRepository
import com.nexias.llms.data.Compatibility
import com.nexias.llms.data.LocalModel
import com.nexias.llms.ui.components.EmptyState

@Composable
fun ModelsScreen(onAddModel: () -> Unit) {
    val models by AppRepository.models.collectAsState()
    val activeModelId by AppRepository.activeModelId.collectAsState()

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddModel,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Add Model") },
                elevation = FloatingActionButtonDefaults.elevation()
            )
        }
    ) { padding ->
        if (models.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding)) {
                EmptyState(
                    icon = Icons.Filled.Widgets,
                    title = "No Models",
                    description = "No local models yet. Add a compatible model to start chatting.",
                    actionLabel = "+ Add Model",
                    onAction = onAddModel
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(models, key = { it.id }) { model ->
                    ModelCard(
                        model = model,
                        isActive = model.id == activeModelId,
                        onRun = { AppRepository.setActiveModel(model.id) },
                        onDelete = { AppRepository.removeModel(model.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ModelCard(
    model: LocalModel,
    isActive: Boolean,
    onRun: () -> Unit,
    onDelete: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth(), shape = MaterialTheme.shapes.medium) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text(model.name, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${model.creator} • ${model.architecture}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                CompatibilityBadge(model.compatibility)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                InfoChip("${model.paramCount}")
                InfoChip(model.quantization)
                InfoChip("${model.sizeMb} MB")
                InfoChip("~${model.estimatedRamMb} MB RAM")
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (isActive) {
                    Button(onClick = onRun, enabled = false) { Text("Active") }
                } else {
                    Button(onClick = onRun) { Text("Run") }
                }
                OutlinedButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}

@Composable
private fun InfoChip(text: String) {
    AssistChip(onClick = {}, enabled = false, label = { Text(text, style = MaterialTheme.typography.labelSmall) })
}

@Composable
private fun CompatibilityBadge(compatibility: Compatibility) {
    val (label, color) = when (compatibility) {
        Compatibility.RECOMMENDED -> "Recommended" to Color(0xFF2ECC71)
        Compatibility.POSSIBLE -> "Possible" to Color(0xFFF1C40F)
        Compatibility.NOT_RECOMMENDED -> "Not recommended" to Color(0xFFE74C3C)
        Compatibility.UNSUPPORTED -> "Unsupported" to Color(0xFF7F8C8D)
    }
    Text(label, color = color, style = MaterialTheme.typography.labelSmall)
}
