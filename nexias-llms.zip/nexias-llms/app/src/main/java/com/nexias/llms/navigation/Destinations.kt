package com.nexias.llms.navigation

sealed class Dest(val route: String, val label: String) {
    data object Home : Dest("home", "Home")
    data object Chat : Dest("chat/{conversationId}", "Chat") {
        fun route(conversationId: String) = "chat/$conversationId"
    }
    data object Models : Dest("models", "Models")
    data object AddModel : Dest("add_model", "Add Model")
    data object History : Dest("history", "History")
    data object Notes : Dest("notes", "Notes")
    data object Messages : Dest("messages", "Messages")
    data object AiPower : Dest("ai_power", "AI Power")
    data object Benchmark : Dest("benchmark", "Benchmark")
    data object Customize : Dest("customize", "Customize")
    data object Settings : Dest("settings", "Settings")
    data object Privacy : Dest("privacy", "Privacy")
    data object DataStorage : Dest("data_storage", "Data & Storage")
    data object About : Dest("about", "About")
    data object Help : Dest("help", "Help")
    data object More : Dest("more", "More")
}
