package com.nexias.llms.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexias.llms.ui.components.SectionCard
import com.nexias.llms.ui.theme.ThemeState

private val swatches = listOf(
    Color(0xFF6C5CE7), Color(0xFF00B894), Color(0xFF0984E3),
    Color(0xFFE17055), Color(0xFFD63031), Color(0xFF636E72)
)

@Composable
fun CustomizeScreen() {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Customize", style = MaterialTheme.typography.headlineSmall)

        // Live preview — updates instantly as controls below change ThemeState
        Text("Preview", style = MaterialTheme.typography.titleMedium)
        LivePreviewCard()

        SectionCard {
            Text("Primary Color", style = MaterialTheme.typography.titleMedium)
            Row(
                modifier = Modifier.padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                swatches.forEach { color ->
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(color, CircleShape)
                            .border(
                                width = if (ThemeState.primaryColor.value == color) 3.dp else 0.dp,
                                color = MaterialTheme.colorScheme.onSurface,
                                shape = CircleShape
                            )
                            .clickable { ThemeState.primaryColor.value = color }
                    )
                }
            }
        }

        SectionCard {
            Text("Corner Radius: ${ThemeState.cornerRadius.value.toInt()}dp", style = MaterialTheme.typography.titleMedium)
            Slider(
                value = ThemeState.cornerRadius.value,
                onValueChange = { ThemeState.cornerRadius.value = it },
                valueRange = 0f..32f
            )

            Text("Font Size: ${"%.2f".format(ThemeState.fontScale.value)}x", style = MaterialTheme.typography.titleMedium)
            Slider(
                value = ThemeState.fontScale.value,
                onValueChange = { ThemeState.fontScale.value = it },
                valueRange = 0.8f..1.4f
            )

            Text("Bubble Radius: ${ThemeState.bubbleRadius.value.toInt()}dp", style = MaterialTheme.typography.titleMedium)
            Slider(
                value = ThemeState.bubbleRadius.value,
                onValueChange = { ThemeState.bubbleRadius.value = it },
                valueRange = 0f..32f
            )
        }

        SectionCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Animations", style = MaterialTheme.typography.titleMedium)
                Switch(
                    checked = ThemeState.animationsEnabled.value,
                    onCheckedChange = { ThemeState.animationsEnabled.value = it }
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Reduced Motion", style = MaterialTheme.typography.titleMedium)
                Switch(
                    checked = ThemeState.reducedMotion.value,
                    onCheckedChange = { ThemeState.reducedMotion.value = it }
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { /* state is already applied live */ }, modifier = Modifier.fillMaxWidth().weight(1f)) {
                Text("Apply")
            }
            OutlinedButton(onClick = { ThemeState.resetToDefaults() }, modifier = Modifier.fillMaxWidth().weight(1f)) {
                Text("Reset")
            }
        }
    }
}

@Composable
private fun LivePreviewCard() {
    val radius = ThemeState.cornerRadius.value.dp
    val bubbleRadius = ThemeState.bubbleRadius.value.dp
    val scale = ThemeState.fontScale.value

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(radius)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                "NEXIAS LLMs",
                fontSize = (18 * scale).sp,
                color = ThemeState.primaryColor.value
            )
            Box(
                modifier = Modifier
                    .background(ThemeState.primaryColor.value.copy(alpha = 0.15f), RoundedCornerShape(bubbleRadius))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    "Hello! How can I help?",
                    fontSize = (14 * scale).sp
                )
            }
            OutlinedTextField(
                value = "",
                onValueChange = {},
                placeholder = { Text("Type message…") },
                enabled = false,
                shape = RoundedCornerShape(bubbleRadius),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
