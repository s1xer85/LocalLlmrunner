package com.nexias.llms.ui.theme

import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color

enum class AppThemeMode { LIGHT, DARK, SYSTEM }

/**
 * Central, mutable theme configuration. Every "Customize" control writes here,
 * and NexiasTheme (Theme.kt) reads from here — so any screen wrapped in
 * NexiasTheme updates live, which is what powers the Customize live preview.
 */
object ThemeState {
    val mode = mutableStateOf(AppThemeMode.SYSTEM)

    val primaryColor = mutableStateOf(Color(0xFF6C5CE7))
    val accentColor = mutableStateOf(Color(0xFF00B894))
    val backgroundLight = mutableStateOf(Color(0xFFFAFAFC))
    val backgroundDark = mutableStateOf(Color(0xFF121318))

    val cornerRadius = mutableStateOf(16f)      // dp, cards
    val bubbleRadius = mutableStateOf(18f)       // dp, chat bubbles
    val fontScale = mutableStateOf(1.0f)         // multiplier
    val density = mutableStateOf(1.0f)           // spacing multiplier
    val animationsEnabled = mutableStateOf(true)
    val reducedMotion = mutableStateOf(false)

    fun resetToDefaults() {
        mode.value = AppThemeMode.SYSTEM
        primaryColor.value = Color(0xFF6C5CE7)
        accentColor.value = Color(0xFF00B894)
        backgroundLight.value = Color(0xFFFAFAFC)
        backgroundDark.value = Color(0xFF121318)
        cornerRadius.value = 16f
        bubbleRadius.value = 18f
        fontScale.value = 1.0f
        density.value = 1.0f
        animationsEnabled.value = true
        reducedMotion.value = false
    }
}
