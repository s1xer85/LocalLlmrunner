package com.nexias.llms.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexias.llms.ui.components.SectionCard

@Composable
fun AboutScreen() {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("NEXIAS LLMs", style = MaterialTheme.typography.headlineSmall)
        Text("Version 0.1.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            "Your Models. Your Device. Your AI.",
            style = MaterialTheme.typography.titleMedium
        )

        SectionCard {
            Text("About the project", style = MaterialTheme.typography.titleMedium)
            Text(
                "NEXIAS LLMs is a local-first, open-source engine for running compatible " +
                    "language models directly on your Android device — no account, no cloud " +
                    "dependency required.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        SectionCard {
            Text("Links", style = MaterialTheme.typography.titleMedium)
            Text("Source code: <add-your-repo-url-here>", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Documentation: <add-your-docs-url-here>", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Report a bug: <add-your-issue-tracker-url-here>", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Contact: <add-your-contact-email-here>", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SectionCard {
            Text("Open Source", style = MaterialTheme.typography.titleMedium)
            Text(
                "Built with Jetpack Compose, Kotlin Coroutines and AndroidX Navigation. " +
                    "Full third-party license list to be generated at release time.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
