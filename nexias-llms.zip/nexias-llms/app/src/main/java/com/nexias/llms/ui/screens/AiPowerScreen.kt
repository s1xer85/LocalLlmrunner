package com.nexias.llms.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexias.llms.data.AppRepository
import com.nexias.llms.data.PowerPreset
import com.nexias.llms.ui.components.SectionCard

@Composable
fun AiPowerScreen() {
    val preset by AppRepository.powerPreset.collectAsState()
    val models by AppRepository.models.collectAsState()
    val activeModelId by AppRepository.activeModelId.collectAsState()
    val model = models.find { it.id == activeModelId }
    var temperature by remember { mutableFloatStateOf(0.7f) }
    var maxTokens by remember { mutableFloatStateOf(512f) }

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("AI Power", style = MaterialTheme.typography.headlineSmall)

        SectionCard {
            Text("Current Model", style = MaterialTheme.typography.titleMedium)
            Text(model?.name ?: "No model selected", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(top = 8.dp)) {
                Column { Text("Params", style = MaterialTheme.typography.labelSmall); Text(model?.paramCount ?: "—") }
                Column { Text("Quant", style = MaterialTheme.typography.labelSmall); Text(model?.quantization ?: "—") }
                Column { Text("Est. RAM", style = MaterialTheme.typography.labelSmall); Text(model?.let { "~${it.estimatedRamMb} MB" } ?: "—") }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                PowerPreset.FAST to "⚡ Fast",
                PowerPreset.BALANCED to "⚖️ Balanced",
                PowerPreset.QUALITY to "🧠 Quality",
                PowerPreset.CUSTOM to "🛠 Custom"
            ).forEach { (value, label) ->
                FilterChip(
                    selected = preset == value,
                    onClick = { AppRepository.powerPreset.value = value },
                    label = { Text(label) }
                )
            }
        }

        SectionCard {
            Text("Temperature: ${"%.2f".format(temperature)}", style = MaterialTheme.typography.titleMedium)
            Slider(value = temperature, onValueChange = { temperature = it }, valueRange = 0f..1.5f)

            Text("Max tokens: ${maxTokens.toInt()}", style = MaterialTheme.typography.titleMedium)
            Slider(value = maxTokens, onValueChange = { maxTokens = it }, valueRange = 64f..2048f)
        }

        Button(onClick = { AppRepository.powerPreset.value = PowerPreset.BALANCED }, modifier = Modifier.fillMaxWidth()) {
            Text("Auto Optimize for This Device")
        }
    }
}
