package com.nexias.llms.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexias.llms.data.AppRepository
import com.nexias.llms.ui.components.SectionCard

@Composable
fun DataStorageScreen() {
    var confirmClearAll by remember { mutableStateOf(false) }
    val models by AppRepository.models.collectAsState()

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Data & Storage", style = MaterialTheme.typography.headlineSmall)

        SectionCard {
            StorageRow("Chat History", "—")
            StorageRow("Notes", "—")
            StorageRow("Models", "${models.sumOf { it.sizeMb }} MB")
            StorageRow("Cache", "—")
        }

        OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Clear Cache") }
        OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Export All Data") }
        OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("Import Backup") }
        OutlinedButton(
            onClick = { confirmClearAll = true },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Delete All Local Data") }
    }

    if (confirmClearAll) {
        AlertDialog(
            onDismissRequest = { confirmClearAll = false },
            title = { Text("Delete all local data?") },
            text = { Text("This permanently removes chats, notes, messages and models from this device. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { confirmClearAll = false }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { confirmClearAll = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun StorageRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label)
        Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

