package com.nexias.llms

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.nexias.llms.navigation.NexiasNavHost
import com.nexias.llms.ui.theme.NexiasTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NexiasTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    NexiasNavHost()
                }
            }
        }
    }
}
