package com.nexias.llms.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexias.llms.navigation.Dest

private data class SettingsGroup(val title: String, val items: List<Pair<String, String>>)

@Composable
fun SettingsScreen(onNavigate: (String) -> Unit) {
    val groups = listOf(
        SettingsGroup("Appearance", listOf("Customize" to Dest.Customize.route)),
        SettingsGroup("AI", listOf("AI Power" to Dest.AiPower.route)),
        SettingsGroup("Performance", listOf("Benchmark" to Dest.Benchmark.route)),
        SettingsGroup("Models", listOf("Model Library" to Dest.Models.route)),
        SettingsGroup("Privacy & Data", listOf(
            "Privacy Center" to Dest.Privacy.route,
            "Data & Storage" to Dest.DataStorage.route
        )),
        SettingsGroup("Support", listOf(
            "Help" to Dest.Help.route,
            "About" to Dest.About.route
        ))
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item { Text("Settings", style = MaterialTheme.typography.headlineSmall) }
        items(groups) { group ->
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    group.title.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        group.items.forEachIndexed { index, (label, route) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onNavigate(route) }
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(label, style = MaterialTheme.typography.bodyLarge)
                                Icon(Icons.Filled.ChevronRight, contentDescription = null)
                            }
                        }
                    }
                }
            }
        }
    }
}

