package com.nexias.llms.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Simple in-memory, process-scoped repository.
 *
 * This is intentionally NOT persisted to disk yet. For a production build,
 * replace the backing MutableStateFlow lists with a Room database
 * (see /data/README.md for the recommended schema) so Chats, Notes,
 * Messages and Model metadata survive app restarts.
 */
object AppRepository {

    // ---- Models -------------------------------------------------------
    private val _models = MutableStateFlow(
        listOf(
            LocalModel(
                name = "Qwen2.5",
                creator = "Alibaba",
                paramCount = "0.6B",
                quantization = "Q4_K_M",
                sizeMb = 420,
                architecture = "Qwen2",
                runtime = "GGUF adapter",
                estimatedRamMb = 650,
                compatibility = Compatibility.RECOMMENDED,
                license = "Apache-2.0"
            ),
            LocalModel(
                name = "Phi-3-mini",
                creator = "Microsoft",
                paramCount = "3.8B",
                quantization = "Q4_0",
                sizeMb = 2100,
                architecture = "Phi3",
                runtime = "GGUF adapter",
                estimatedRamMb = 2900,
                compatibility = Compatibility.POSSIBLE,
                license = "MIT"
            )
        )
    )
    val models: StateFlow<List<LocalModel>> = _models

    private val _activeModelId = MutableStateFlow(_models.value.firstOrNull()?.id)
    val activeModelId: StateFlow<String?> = _activeModelId

    fun setActiveModel(id: String) { _activeModelId.value = id }
    fun addModel(model: LocalModel) { _models.value = _models.value + model }
    fun removeModel(id: String) {
        _models.value = _models.value.filterNot { it.id == id }
        if (_activeModelId.value == id) _activeModelId.value = _models.value.firstOrNull()?.id
    }

    // ---- Conversations --------------------------------------------------
    private val _conversations = MutableStateFlow<List<Conversation>>(emptyList())
    val conversations: StateFlow<List<Conversation>> = _conversations

    fun addConversation(conversation: Conversation) {
        _conversations.value = listOf(conversation) + _conversations.value
    }

    fun updateConversation(updated: Conversation) {
        _conversations.value = _conversations.value.map { if (it.id == updated.id) updated else it }
    }

    fun deleteConversation(id: String) {
        _conversations.value = _conversations.value.filterNot { it.id == id }
    }

    // ---- Notes ----------------------------------------------------------
    private val _notes = MutableStateFlow<List<NoteItem>>(emptyList())
    val notes: StateFlow<List<NoteItem>> = _notes

    fun addNote(note: NoteItem) { _notes.value = listOf(note) + _notes.value }
    fun updateNote(updated: NoteItem) {
        _notes.value = _notes.value.map { if (it.id == updated.id) updated else it }
    }
    fun deleteNote(id: String) { _notes.value = _notes.value.filterNot { it.id == id } }

    // ---- Saved prompts / Messages ---------------------------------------
    private val _prompts = MutableStateFlow(
        listOf(
            SavedPrompt(title = "Coding Assistant", content = "You are a precise, expert coding assistant.", category = PromptCategory.SYSTEM, favorite = true),
            SavedPrompt(title = "Study Helper", content = "Explain concepts simply with examples.", category = PromptCategory.SYSTEM, favorite = true)
        )
    )
    val prompts: StateFlow<List<SavedPrompt>> = _prompts

    fun addPrompt(prompt: SavedPrompt) { _prompts.value = listOf(prompt) + _prompts.value }
    fun updatePrompt(updated: SavedPrompt) {
        _prompts.value = _prompts.value.map { if (it.id == updated.id) updated else it }
    }
    fun deletePrompt(id: String) { _prompts.value = _prompts.value.filterNot { it.id == id } }

    // ---- Performance / AI Power ------------------------------------------
    val performanceProfile = MutableStateFlow(PerformanceProfile.BALANCED)
    val powerPreset = MutableStateFlow(PowerPreset.BALANCED)
    val lowRamMode = MutableStateFlow(false)

    // ---- Privacy toggles --------------------------------------------------
    val cloudAiEnabled = MutableStateFlow(false)
    val analyticsEnabled = MutableStateFlow(false)
    val crashReportsEnabled = MutableStateFlow(false)
    val onlineModelDiscoveryEnabled = MutableStateFlow(false)
    val localOnlyMode = MutableStateFlow(true)
}
