package com.nexias.llms.runtime

import com.nexias.llms.data.LocalModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * A RuntimeAdapter knows how to load a specific model format/runtime
 * (e.g. GGUF via llama.cpp, MLC, ExecuTorch, ONNX) and stream tokens back.
 *
 * To add a REAL local inference engine:
 *   1. Add the native runtime as a dependency (e.g. llama.cpp Android bindings,
 *      published as an AAR, or built via CMake/NDK in this module).
 *   2. Implement this interface, wrapping the native load/generate calls.
 *   3. Register it in RuntimeManager below.
 *
 * The rest of the app (Chat screen, Model Manager, AI Power) only ever talks
 * to this interface, so swapping in a real engine does not require touching UI code.
 */
interface RuntimeAdapter {
    val id: String
    val displayName: String

    suspend fun loadModel(model: LocalModel): Result<Unit>
    fun unloadModel()
    fun generate(prompt: String, temperature: Float, maxTokens: Int): Flow<String>
}

/**
 * Mock adapter used until a real native runtime (llama.cpp / MLC / etc.) is wired in.
 * Streams back a placeholder response token-by-token so the whole chat pipeline,
 * including stop/regenerate/streaming UI, can be built and tested end-to-end now.
 */
class MockRuntimeAdapter : RuntimeAdapter {
    override val id = "mock"
    override val displayName = "Mock Runtime (no real inference yet)"

    override suspend fun loadModel(model: LocalModel): Result<Unit> {
        delay(400)
        return Result.success(Unit)
    }

    override fun unloadModel() { /* no-op */ }

    override fun generate(prompt: String, temperature: Float, maxTokens: Int): Flow<String> = flow {
        val reply = "This is a placeholder response from the mock runtime. " +
            "Wire up a real GGUF/llama.cpp adapter in RuntimeAdapter.kt to get actual model output. " +
            "Your prompt was ${prompt.length} characters long."
        for (word in reply.split(" ")) {
            emit("$word ")
            delay(35)
        }
    }
}

object RuntimeManager {
    private val adapters = mutableListOf<RuntimeAdapter>(MockRuntimeAdapter())
    var active: RuntimeAdapter = adapters.first()
        private set

    fun available(): List<RuntimeAdapter> = adapters
    fun register(adapter: RuntimeAdapter) { adapters += adapter }
    fun select(id: String) {
        adapters.find { it.id == id }?.let { active = it }
    }
}
