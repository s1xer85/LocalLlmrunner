package com.nexias.llms.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.nexias.llms.data.AppRepository
import com.nexias.llms.data.Compatibility
import com.nexias.llms.data.LocalModel

private enum class AddStep { CHOOSE_SOURCE, ANALYZING, RESULT }

@Composable
fun AddModelScreen(onDone: () -> Unit) {
    var step by remember { mutableStateOf(AddStep.CHOOSE_SOURCE) }
    var pendingModel by remember { mutableStateOf<LocalModel?>(null) }

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        when (step) {
            AddStep.CHOOSE_SOURCE -> {
                Text("+ Add Model", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Choose where to import a compatible local model from.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                listOf("Select From Device", "Import File", "Model Folder", "Model URL", "Repository").forEach { source ->
                    OutlinedButton(
                        onClick = {
                            // Simulated selection — a real implementation opens a
                            // file/document picker (SAF) or a URL/repo input dialog here.
                            pendingModel = LocalModel(
                                name = "Imported Model",
                                creator = "Unknown",
                                paramCount = "1.5B",
                                quantization = "Q4_K_M",
                                sizeMb = 950,
                                architecture = "Llama",
                                runtime = "GGUF adapter",
                                estimatedRamMb = 1400,
                                compatibility = Compatibility.POSSIBLE
                            )
                            step = AddStep.ANALYZING
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(source) }
                }
            }

            AddStep.ANALYZING -> {
                Text("Model Analysis", style = MaterialTheme.typography.headlineSmall)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Detecting format, architecture, quantization…")
                        Text(
                            "Estimating RAM needs and runtime compatibility for this device…",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Button(onClick = { step = AddStep.RESULT }, modifier = Modifier.fillMaxWidth()) {
                    Text("Continue")
                }
            }

            AddStep.RESULT -> {
                val model = pendingModel
                if (model != null) {
                    Text("Analysis Complete", style = MaterialTheme.typography.headlineSmall)
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Format: GGUF")
                            Text("Architecture: ${model.architecture}")
                            Text("Parameters: ${model.paramCount}")
                            Text("Quantization: ${model.quantization}")
                            Text("Size: ${model.sizeMb} MB")
                            Text("Estimated RAM: ~${model.estimatedRamMb} MB")
                            Text(
                                "🟡 Possible — this model may run, but performance depends on available RAM on your device.",
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    Button(
                        onClick = {
                            AppRepository.addModel(model)
                            onDone()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Add to Model Library") }
                }
            }
        }
    }
}
