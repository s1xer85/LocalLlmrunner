package com.nexias.llms.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private val beginnerTopics = listOf(
    "How to add a model",
    "What is GGUF?",
    "What is quantization?",
    "How much RAM do I need?",
    "Why is my model slow?",
    "Why won't my model load?",
    "How to reduce RAM usage",
    "How to change AI Power",
    "How to customize the UI",
    "How to use Notes",
    "How to use Messages",
    "How to protect privacy"
)

private val advancedTopics = listOf(
    "Runtime adapters",
    "Context length",
    "CPU threads",
    "Memory troubleshooting",
    "Benchmarking"
)

@Composable
fun HelpScreen() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("Help", style = MaterialTheme.typography.headlineSmall) }
        item { Text("Beginner Guides", style = MaterialTheme.typography.titleMedium) }
        items(beginnerTopics) { topic -> HelpRow(topic) }
        item { Text("Advanced", style = MaterialTheme.typography.titleMedium) }
        items(advancedTopics) { topic -> HelpRow(topic) }
    }
}

@Composable
private fun HelpRow(topic: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Text(topic, modifier = Modifier.padding(16.dp))
    }
}
