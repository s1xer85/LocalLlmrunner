# NEXIAS LLMs

Local-first Android app foundation — Kotlin + Jetpack Compose.

Your Models. Your Device. Your AI.

## What's in this project

A real, buildable Android app skeleton with:

- Bottom-nav app shell: Home, Models, History, More
- Screens: Home, Chat (streaming), Models, Add Model (compatibility check flow),
  History, Notes, Messages (saved prompts), AI Power, Benchmark, Customize
  (with **live preview**), Settings, Privacy Center, Data & Storage, About, Help
- A `RuntimeAdapter` interface (`runtime/RuntimeAdapter.kt`) so a real local
  inference engine (llama.cpp/GGUF, MLC, etc.) can be plugged in without
  touching any UI code. Ships with a `MockRuntimeAdapter` so the whole chat
  pipeline (streaming, stop, regenerate) already works end-to-end.
- In-memory repository (`data/AppRepository.kt`) — swap for Room to persist
  data across app restarts (see "Next steps" below).
- A GitHub Actions workflow that builds a debug APK on every push, no local
  Android Studio required.

## How to turn this into an installable APK (no computer setup needed)

1. **Create a new GitHub repository** (public or private).
2. **Unzip** the file you downloaded from this chat.
3. **Upload the unzipped contents** to the repo — either:
   - drag-and-drop all files/folders into the GitHub web UI ("Add file" →
     "Upload files"), or
   - `git init && git add . && git commit -m "Initial commit" && git remote add origin <your-repo-url> && git push -u origin main`
4. Go to the **Actions** tab of your repository. The "Build APK" workflow
   runs automatically on push (or click "Run workflow" to trigger it
   manually).
5. When the run finishes (green check), open it and download the
   **`nexias-llms-debug-apk`** artifact — that's your installable APK.
6. Transfer the APK to your Android phone and tap it to install (you'll need
   to allow "install unknown apps" for whichever app you use to open it).

No Android Studio, no local SDK, no signing keys needed for this debug build.

## Project structure

```
app/src/main/java/com/nexias/llms/
├── MainActivity.kt
├── navigation/        NexiasNavHost.kt, Destinations.kt
├── ui/
│   ├── screens/        one file per screen
│   ├── components/     shared composables (SectionCard, EmptyState)
│   └── theme/           Theme.kt, ThemeState.kt  ← live-preview customization state
├── data/                AppRepository.kt, Models.kt (in-memory data layer)
└── runtime/             RuntimeAdapter.kt (plug in real model inference here)
```

## Next steps to reach full production spec

This scaffold intentionally does **not** yet include:

- **Real on-device inference.** `MockRuntimeAdapter` returns placeholder text.
  To run actual GGUF models, integrate `llama.cpp`'s Android bindings (JNI/NDK)
  and implement `RuntimeAdapter` against it — the chat UI already streams
  tokens correctly, it just needs a real source.
- **Persistence.** Chats/Notes/Prompts currently live in memory and reset
  when the app restarts. Swap `AppRepository`'s in-memory lists for a Room
  database.
- **Device analysis / auto performance profile** (Ultra Low → Maximum) —
  `AppRepository.performanceProfile` exists as a hook; wire it to
  `ActivityManager.getMemoryInfo()` on first launch.
- **File import (SAF), model URL/repository download**, voice input/output,
  and export/import of backups.
- App icon, splash screen, and release signing config for a Play-Store-ready
  build.

Each of these can be added incrementally without restructuring the app —
that separation is why the Runtime Adapter and Repository layers exist.

## Building locally instead (optional)

If you do have Android Studio: open this folder as a project, let Gradle
sync, and run on a device/emulator. Minimum SDK 24, target/compile SDK 34.
